"""This module contains

    1. a dictionary with the string that needs to be abbreviated as
    keys and their cooresponding abbreviation as value

    2. a function that abbreviates the words mentioned in the
    dictionary

"""

def abbreviate():
	"""
	"""
	raise NotImplementedError